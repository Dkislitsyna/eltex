#!/bin/bash

CONF_FILE="$PWD/observer.conf"
LOG_FILE="$PWD/observer.log"

log_msg() {
    echo "$(date '+%F %T') $1" >> "$LOG_FILE"
}

is_running() {
    local script_name="$1"

    for pid_dir in /proc/[0-9]*; do
        [[ -r "$pid_dir/cmdline" ]] || continue

        cmdline=$(tr '\0' ' ' < "$pid_dir/cmdline" 2>/dev/null)

        if [[ "$cmdline" == *"$script_name"* ]]; then
            return 0
        fi
    done

    return 1
}

while IFS= read -r script || [[ -n "$script" ]]; do
    [[ -z "$script" ]] && continue

    if ! is_running "$script"; then
        nohup "./$script" > /dev/null 2>&1 &
        log_msg "Перезапуск $script"
    fi
done < "$CONF_FILE"
